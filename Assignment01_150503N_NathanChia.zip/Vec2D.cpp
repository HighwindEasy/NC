#include "Vec2D.h"

Vec2D::Vec2D()
{

}

Vec2D::Vec2D(double x, double y)
{

}

Vec2D::~Vec2D()
{

}
